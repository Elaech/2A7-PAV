create trigger ALBUMS_BIR
    before insert
    on ALBUMS
    for each row
BEGIN
  SELECT albums_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

