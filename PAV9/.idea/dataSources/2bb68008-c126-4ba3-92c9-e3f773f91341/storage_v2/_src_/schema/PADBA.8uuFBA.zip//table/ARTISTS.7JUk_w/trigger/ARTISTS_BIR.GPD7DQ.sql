create trigger ARTISTS_BIR
    before insert
    on ARTISTS
    for each row
BEGIN
  SELECT artists_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

